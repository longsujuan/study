/*
2019��10��7�� 17:06:05
ʵ��strcat�����Ĺ���
*/

#include <stdio.h>
#define N 50

void m_strcat(char str1[], char str2[])
{
	int i,j;
	char merge[N];
	for(i=0; str1[i]!='\0' && i<N; i++)
	{
		merge[i] = str1[i];
	}
	for(j=0; str2[j]!='\0' && i<N; j++)
	{
		merge[i++] = str2[j];
	}
	printf("%d\n", i);
	for(j=0; j<i; j++)
	{
		printf("%c", merge[j]);
	}
	putchar('\n');
}

int main(void)
{
	char str1[]="hello world!", str2[]="My name is lijianqing";
	m_strcat(str1, str2);

	return 0;
}
