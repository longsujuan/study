#include <stdio.h>

double sum(int n)
{
	int i;
	double p=1.0, q=2.0, temp;
	double sum = 0;
	for(i=0; i<n; i++)
	{
		sum += q/p;
		temp = q;
		q = q+p;
		p = temp;
	}
	return sum;
}

int main(void)
{
	int n = 3;
	double num;
	num = sum(n);
	printf("%.4lf\n", num);

	return 0;
}