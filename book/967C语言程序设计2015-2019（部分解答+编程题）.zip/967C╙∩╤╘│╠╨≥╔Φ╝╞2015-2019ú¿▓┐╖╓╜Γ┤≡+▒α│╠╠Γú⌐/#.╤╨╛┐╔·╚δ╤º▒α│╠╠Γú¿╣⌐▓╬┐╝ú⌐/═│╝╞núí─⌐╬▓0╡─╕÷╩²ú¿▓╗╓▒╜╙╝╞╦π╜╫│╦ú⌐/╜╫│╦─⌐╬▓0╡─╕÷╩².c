#include <stdio.h>

int main(void)
{
	long sum, n;
	scanf("%ld", &n);
	sum = 0;
	while(n>0)
	{
		(n-5>=5)?(n-=5, sum++):(n=0);
		
	}
	printf("%ld", sum);

	return 0;
}
