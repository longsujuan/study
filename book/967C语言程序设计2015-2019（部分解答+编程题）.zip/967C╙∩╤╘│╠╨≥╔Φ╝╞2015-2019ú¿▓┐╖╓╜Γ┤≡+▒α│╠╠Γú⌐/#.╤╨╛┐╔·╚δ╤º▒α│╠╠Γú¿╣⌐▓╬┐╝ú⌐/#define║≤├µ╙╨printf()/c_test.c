#include <stdio.h>
#define PR(ar) printf("%d",ar)  --ע��û��;��

int main()
{
	int j, a[]={1,3,5,7,9,11};
	int *p = a+2;
	for(j=3; j; j--)
	{
		switch(j)
		{
		case 1:
		case 2:PR(*p++); break;
		case 3:PR(*(--p));
		}
	}

	return 0;
}